from django.apps import AppConfig


class RestbasicsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'restBasicsApp'
